---
hide:
  - navigation
---

# "_Semistrukturierte Dateiformate_" – Aufgabenübersicht

## Ausgangslage und Ziele

Das Bistro **Küche & Bar** erhält einen Artikelkatalog in unterschiedlichen Formaten.
Ihr vergleicht seine Darstellung, prüft und bearbeitet XML-Daten und wertet sie in
separaten Aufgaben mit XPath und XSLT aus. Der gemeinsame
[Datenvertrag](DATA_CONTRACT.md) beschreibt einen Unterrichtsfall, keinen Branchenstandard.

**Aufbau, Wohlgeformtheit, DTD und DOM bilden jetzt eine gemeinsame XML-Aufgabe.**
Sie ist eine reine GK-Aufgabe für **4 Unterrichtseinheiten à 50 Minuten** mit eigener Angabe, Checkliste und Abgabe. XPath und XSLT bleiben eigenständige
Aufgaben. Der umfangreichere Import mit Geschäftsregeln und JSON-Ausgabe ist eine
freiwillige Anschlussaufgabe; er ist für keine der vier regulären Aufgaben Voraussetzung.

## Aufgaben

| Reihenfolge | Aufgabe | Ergebnis |
| --- | --- | --- |
| 1 | [Datenformate im Vergleich](01_Datenformate_im_Vergleich/TASK.md) | Begründete Formatwahl und Datenvergleich. |
| 2 | [XML-Katalog prüfen und bearbeiten](02_XML/TASK.md) | Zwei XML-Reparaturen, ergänzte DTD und drei DOM-Funktionen mit kurzem Prüfprotokoll (4 UE, GK). |
| 3 | [XPath](02_XML/05_XPath/TASK.md) | Sechs eigene Abfragen mit Sollwerten. |
| 4 | [XSLT](02_XML/06_XSLT/TASK.md) | Aus XML erzeugte HTML-Preisliste. |

[Optional: XML-Import und Streaming](02_XML/04_Parsing/TASK.md) vertieft das Einlesen
mit Datentypen, Geschäftsregeln, Fehlerbehandlung und großen Dateien. Diese Anschlussaufgabe
gehört weder zum Grundbereich noch zu den EK-Pflichtnachweisen der regulären Aufgaben.

## Einrichtung und Material

Für die **XML-Aufgabe allein** verwendet ihr das reduzierte
[XML-Materialpaket](02_XML/material.zip) mit [eigener Anleitung](02_XML/TASK.md#voraussetzungen-und-einrichtung).
Es benötigt lxml und defusedxml. Ein Saxon-Prozessor ist dafür nicht erforderlich.

Für **Formatvergleich, XPath, XSLT oder den optionalen Import** verwendet ihr das
[gemeinsame Materialpaket](material.zip). Entpackt es in einen separaten Ordner und
arbeitet im enthaltenen Ordner `material`. Überschreibt damit keine bereits bearbeiteten
`work/`-Dateien. Die gemeinsamen Katalogdateien sind identisch; das XML-Paket enthält nur die für die GK-Aufgabe benötigte Auswahl und passende Gerüste. Für den optionalen
Import übernehmt ihr eure vervollständigte `work/catalog.dtd` in dessen Arbeitsordner.

Voraussetzungen sind Python-Grundkenntnisse, Dateien und Kommandozeile; für XSLT
genügen zusätzlich grundlegende HTML-Kenntnisse. Eine Datenbank wird nicht benötigt.

### Gemeinsames Material unter Windows / PowerShell

Python 3.14 muss installiert sein (getestet: 3.14.7). Prüft `py -3.14 --version`.
Falls der Launcher eure Installation nicht findet, verwendet für die venv-Erstellung
den vollständigen Pfad zu deren `python.exe` anstelle von `py -3.14`; in PowerShell
steht `&` vor dem in Anführungszeichen gesetzten Pfad.

```powershell
py -3.14 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -X utf8 tools.py versions
.\.venv\Scripts\python.exe -X utf8 tools.py parse data/catalog.xml
```

Linux/macOS: `python3.14 -m venv .venv`, danach `.venv/bin/python` verwenden.
Die macOS-Variante wurde nicht separat getestet. Die Docker-Alternative lautet:

```bash
docker compose build
docker compose run --rm tools python tools.py versions
docker compose run --rm tools python tools.py parse data/catalog.xml
```

Es genügt **ein** Ausführungsweg. In den Aufgaben steht `python` für den Interpreter
eurer venv. Im Container setzt ihr `docker compose run --rm tools` davor.

| Technik | Verwendete Basis | Zweck |
| --- | --- | --- |
| Python | 3.14.7 | Gemeinsame Laufzeit. |
| XML / DTD | XML 1.0, fünfte Ausgabe | Struktur, Wohlgeformtheit und Validierung. |
| DOM | Python `xml.dom.minidom` über defusedxml 0.7.1 | Knoten, Attribute und Text bearbeiten. |
| lxml | 6.1.3 | Einlesen und explizite DTD-Validierung. |
| XPath / XSLT | 3.1 / 3.0 mit SaxonC-HE 13.0.0 | Separate Abfragen und Transformationen. |
| CSV / JSON | Vereinbarter CSV-Dialekt nach RFC 4180 / JSON nach RFC 8259 | Datenformate vergleichen. |

Die [Primärquellen](SOURCES.md) erläutern die Versionsentscheidungen. lxml liefert
selbst nur XPath 1.0/XSLT 1.0; für die beiden entsprechenden Aufgaben verwendet ihr
deshalb die Saxon-Werkzeuge des gemeinsamen Pakets. Öffnet das lokal erzeugte HTML
im Browser; eine XSLT-Verarbeitung im Browser wird nicht vorausgesetzt.

## Arbeitsweise und Abgabe

Jede Aufgabe beginnt mit den unveränderten Originalen in `data/`; eigene Ergebnisse
gehören nach `out/`. So müssen spätere XPath-/XSLT-Sollwerte nicht an die DOM-Änderungen
angepasst werden. Verwendet UTF-8 explizit und bei Preisberechnungen Dezimalarithmetik.
In der XML-GK-Aufgabe ergänzen die Lernenden DTD- und DOM-Gerüste. In den weiteren Aufgaben entwickeln sie Abfragen und Transformationen selbst.

Die Werkzeuge lehnen DOCTYPE und benutzerdefinierte Entities ab. Eine DTD wird separat
als lokale Datei übergeben. Verwendet nur gelieferte oder selbst erstellte lokale DTDs
und Stylesheets. Fertige Werkzeuge ersetzen nicht die Erklärung eurer Lösung.

**Einzelarbeit.** Gebt je beauftragter Praxisaufgabe eure Arbeitsdateien, relevante
Ergebnisse und ein kurzes Protokoll ab. Die XML-Aufgabe hat **eine** gemeinsame Abgabe
für ihre drei Abschnitte. Jeder Test nennt Eingabe, Aktion, Soll, Ist und Begründung.
Notiert bei Lernversuchen zuerst eine Vorhersage. Kennzeichnet Quellen und KI-Unterstützung;
keine `.venv`, Caches oder riesigen Testdateien abgeben. Die genaue Abgabe und das
Abgabegespräch sind in den jeweiligen Aufgaben beschrieben.

## Bewertungsvorschlag

**Vor Unterrichtseinsatz durch die Lehrkraft festzulegen.** Die folgende Übersicht
beschreibt das gesamte Modul und erzeugt keine zusätzliche Note. Wird nur die XML-Aufgabe
beauftragt, gelten ausschließlich deren [Bewertung](02_XML/TASK.md#bewertungsvorschlag)
und [Checkliste](02_XML/CHECK.md). XPath, XSLT und Import werden dort nicht mitbewertet.
Die drei XML-Abschnitte sind keine drei zusätzlichen Praxisaufgaben. Die Stufen bauen aufeinander auf.

### Grundlegend überwiegend

- [ ] Formatvergleich mit begründeter Entscheidung und nachvollziehbaren Beispielen bearbeitet.
- [ ] Gemeinsame XML-Aufgabe mindestens auf Stufe „Grundlegend überwiegend“ erfüllt.
- [ ] Mindestens drei korrekte XPath-Abfragen und eine aus XML erzeugte HTML-Tabelle lauffähig.

### Grundlegend vollständig

- [ ] Grundaufgaben des Formatvergleichs und der gemeinsamen XML-Aufgabe vollständig erfüllt.
- [ ] Alle sechs XPath-Abfragen und die gefilterte, sortierte XSLT-Ausgabe mit Sollwerten nachgewiesen.
- [ ] Ergebnisse reproduzierbar; Lernversuche, Fragestellungen und Abgabegespräche nachvollziehbar.

Die folgenden erweiterten Kriterien betreffen ausschließlich die separaten XPath-/XSLT-Aufgaben.

### Erweitert überwiegend

- [ ] Namespace-Abfragen bei XPath korrekt bearbeitet und erklärt.

### Erweitert vollständig

- [ ] XSLT-Ausgabe nach Kategorien gruppiert, mit Parameter und korrektem Dezimal-Warenwert; leere Gruppen und Ergebnisse sinnvoll behandelt.
- [ ] XPath-3.1-Map mit Kategorienanzahlen umgesetzt und erweiterte Konzepte erklärt.

Der optionale Import und sein Streaming-Versuch sind zusätzliche Lernangebote ohne
Pflichtnachweise in dieser Bewertung. [Gesamtcheckliste](CHECK.md).

*Mit KI-Unterstützung erstellt. Version 20260920v1 – Bewertung als Unterrichtsvorschlag.*
