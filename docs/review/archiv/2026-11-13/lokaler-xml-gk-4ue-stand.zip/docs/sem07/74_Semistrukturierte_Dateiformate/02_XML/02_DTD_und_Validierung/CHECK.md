# DTD und Validierung

Dieser Bereich ist jetzt Teil der gemeinsamen Aufgabe **XML-Katalog prüfen und bearbeiten**.

- [Gesamte XML-Aufgabe](../TASK.md)
- [Abschnitt: DTD und Validierung](../TASK.md#2-struktur-mit-einer-dtd-absichern)
- [Gemeinsame Checkliste](../CHECK.md)
- [XML-Arbeitsmaterial](../material.zip)

Es gibt eine gemeinsame Abgabe und Bewertung. Hier ist keine zusätzliche Einzelaufgabe zu bearbeiten.
