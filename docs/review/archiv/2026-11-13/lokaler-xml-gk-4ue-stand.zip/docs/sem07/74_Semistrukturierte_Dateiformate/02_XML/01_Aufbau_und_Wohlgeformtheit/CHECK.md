# Aufbau und Wohlgeformtheit

Dieser Bereich ist jetzt Teil der gemeinsamen Aufgabe **XML-Katalog prüfen und bearbeiten**.

- [Gesamte XML-Aufgabe](../TASK.md)
- [Abschnitt: Aufbau und Wohlgeformtheit](../TASK.md#1-xml-verstehen-und-reparieren)
- [Gemeinsame Checkliste](../CHECK.md)
- [XML-Arbeitsmaterial](../material.zip)

Es gibt eine gemeinsame Abgabe und Bewertung. Hier ist keine zusätzliche Einzelaufgabe zu bearbeiten.
