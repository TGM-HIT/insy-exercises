# DOM

Dieser Bereich ist jetzt Teil der gemeinsamen Aufgabe **XML-Katalog prüfen und bearbeiten**.

- [Gesamte XML-Aufgabe](../TASK.md)
- [Abschnitt: DOM](../TASK.md#3-katalog-mit-dom-bearbeiten-und-erneut-prufen)
- [Gemeinsame Checkliste](../CHECK.md)
- [XML-Arbeitsmaterial](../material.zip)

Es gibt eine gemeinsame Abgabe und Bewertung. Hier ist keine zusätzliche Einzelaufgabe zu bearbeiten.
