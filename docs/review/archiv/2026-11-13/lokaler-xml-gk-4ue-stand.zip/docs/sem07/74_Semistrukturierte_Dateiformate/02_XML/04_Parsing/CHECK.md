# Selbstkontrolle: optionaler XML-Import

Freiwillige Nachweise zur [Anschlussaufgabe](TASK.md); keine zusätzlichen Pflichtkriterien
der [XML-Bewertung](../TASK.md#bewertungsvorschlag) oder der Modulbewertung.

## Import

- [ ] Struktur und Geschäftsregeln geprüft; korrekten JSON-Import erzeugt.
- [ ] Sollwerte, Fehlerfälle, leere Eingabe und unveränderte Ausgabe bei Fehler nachgewiesen.
- [ ] Tests und Kontrollfragen nachvollziehbar dokumentiert.

## Zusätzliche Vertiefung

- [ ] Großen Katalog ereignisweise ausgewertet und Speicherverhalten erklärt.
