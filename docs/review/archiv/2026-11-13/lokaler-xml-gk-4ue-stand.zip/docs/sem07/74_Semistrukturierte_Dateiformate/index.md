# Semistrukturierte Dateiformate

Ein Lieferantenkatalog verbindet vier Praxisaufgaben: Datenformate vergleichen,
XML prüfen und bearbeiten, mit XPath abfragen und mit XSLT darstellen.

- [Aufgabenübersicht, Einrichtung und Bewertungsvorschlag](TASK.md)
- [XML-Katalog: GK-Aufgabe zu Aufbau, DTD und DOM in 4 UE](02_XML/TASK.md)
- [Gesamtcheckliste](CHECK.md)
- [XML-Materialpaket](02_XML/material.zip) · [Material für die weiteren Aufgaben](material.zip)
- [Datenvertrag](DATA_CONTRACT.md) · [Primärquellen](SOURCES.md)

Der [XML-Import mit Streaming](02_XML/04_Parsing/TASK.md) ist eine freiwillige Anschlussaufgabe.
Die Bewertung bleibt ein Vorschlag für die Lehrkraft.
