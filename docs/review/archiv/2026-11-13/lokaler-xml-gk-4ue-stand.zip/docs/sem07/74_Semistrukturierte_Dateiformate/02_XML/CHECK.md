# Checkliste: XML-Katalog prüfen und bearbeiten

**GK-Aufgabe · 4 Unterrichtseinheiten à 50 Minuten · Einzelarbeit.**
Bewertungsvorschlag für [die XML-Aufgabe](TASK.md), vor Unterrichtseinsatz durch die
Lehrkraft festzulegen. Die Stufen bauen aufeinander auf; Gerüste und Hilfen sind erlaubt.

## Grundlegend überwiegend

- [ ] Beide XML-Syntaxfehler repariert und die korrigierten Dateien erfolgreich eingelesen.
- [ ] Die drei DTD-Deklarationen ergänzt: Normal- und Leerkatalog sind gültig, der Katalog ohne Namen ist ungültig.
- [ ] Alle drei DOM-Änderungen umgesetzt; die gespeicherte Ausgabe ist wohlgeformt und DTD-gültig.
- [ ] Wohlgeformtheit, DTD-Gültigkeit und fachliche Korrektheit am Beispiel des negativen Preises unterschieden.

## Grundlegend vollständig

- [ ] Wurzelelement, Attribut und Text am Katalog richtig benannt und alle drei Kurzfragen fachlich richtig beantwortet.
- [ ] Übrige Inhalte erhalten; A200 mit dem Original verglichen, Original unverändert und zweiter Lauf mit Bestand 15 sowie genau einem neuen Tag nachgewiesen.
- [ ] Alle acht Testzeilen mit Soll, Ist und kurzer Erklärung ausgefüllt; Arbeitsdateien und XML-Ergebnisse vollständig und erneut ausführbar abgegeben.
