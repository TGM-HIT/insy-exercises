# Checkliste: Semistrukturierte Dateiformate

**Bewertungsvorschlag, vor Unterrichtseinsatz durch die Lehrkraft festzulegen.**
Diese Übersicht zur [Aufgabenreihe](TASK.md) erzeugt keine zusätzliche Note.
Für eine eigenständige XML-Abgabe gilt nur die [XML-Checkliste](02_XML/CHECK.md).
Die Stufen bauen aufeinander auf. Der optionale Import und Streaming sind keine Pflichtnachweise.

## Grundlegend überwiegend

- [ ] Formatvergleich mit begründeter Entscheidung und nachvollziehbaren Beispielen bearbeitet.
- [ ] Gemeinsame XML-Aufgabe mindestens auf Stufe „Grundlegend überwiegend“ erfüllt.
- [ ] Mindestens drei korrekte XPath-Abfragen und eine aus XML erzeugte HTML-Tabelle lauffähig.

## Grundlegend vollständig

- [ ] Grundaufgaben des Formatvergleichs und der gemeinsamen XML-Aufgabe vollständig erfüllt.
- [ ] Alle sechs XPath-Abfragen und die gefilterte, sortierte XSLT-Ausgabe mit Sollwerten nachgewiesen.
- [ ] Ergebnisse reproduzierbar; Lernversuche, Fragestellungen und Abgabegespräche nachvollziehbar.

Die erweiterten Kriterien betreffen ausschließlich die separaten XPath-/XSLT-Aufgaben.

## Erweitert überwiegend

- [ ] Namespace-Abfragen bei XPath korrekt bearbeitet und erklärt.

## Erweitert vollständig

- [ ] XSLT-Ausgabe nach Kategorien gruppiert, mit Parameter und korrektem Dezimal-Warenwert; leere Gruppen und Ergebnisse sinnvoll behandelt.
- [ ] XPath-3.1-Map mit Kategorienanzahlen umgesetzt und erweiterte Konzepte erklärt.
