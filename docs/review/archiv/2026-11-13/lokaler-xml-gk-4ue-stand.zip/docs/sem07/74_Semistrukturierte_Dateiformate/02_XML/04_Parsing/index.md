# Optional: XML-Import und Streaming

Freiwillige Anschlussaufgabe zu Datentypen, Geschäftsregeln, JSON-Export und großen Dateien.
Kein Bestandteil der gemeinsamen XML-Abgabe oder ihrer GK-/EK-Bewertung.

[Aufgabe](TASK.md) · [Selbstkontrolle](CHECK.md) · [Gemeinsame XML-Aufgabe](../TASK.md)
