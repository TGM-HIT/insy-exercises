# XML

## Gemeinsame Praxisaufgabe

[XML-Katalog prüfen und bearbeiten](TASK.md) verbindet Aufbau und Wohlgeformtheit,
DTD-Validierung und DOM-Änderungen als **reine GK-Aufgabe für 4 Unterrichtseinheiten à 50 Minuten** mit vorbereiteten Gerüsten. Es gibt eine Angabe, eine Abgabe und eine Bewertung.

[Checkliste](CHECK.md) · [XML-Arbeitsmaterial](material.zip)

## Weitere Aufgaben

- [XPath](05_XPath/TASK.md)
- [XSLT](06_XSLT/TASK.md)
- [Optional: XML-Import und Streaming](04_Parsing/TASK.md)

Diese Aufgaben sind kein Bestandteil der gemeinsamen XML-Abgabe.
[Modulübersicht und Einrichtung für die weiteren Aufgaben](../TASK.md).
