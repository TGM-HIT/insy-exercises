# Datenvertrag: XML-Artikelkatalog

Der Katalog verwendet XML 1.0 und UTF-8. `catalog` trägt die Pflichtattribute
`currency="EUR"` und `updated` (Datum als `YYYY-MM-DD`) und enthält null bis viele
`product`-Elemente. Jedes Produkt hat eine eindeutige, XML-ID-kompatible `id`
(z. B. `A100`) und das Pflichtattribut `active` mit `true` oder `false`.

Diese Kindelemente stehen genau in der folgenden Reihenfolge:

| Element | Häufigkeit und Inhalt |
| --- | --- |
| `name` | einmal, Produktname als Text |
| `category` | einmal, Kategorie als Text |
| `unit` | einmal, Einheit als Text |
| `price` | einmal, Preis als Text mit Dezimalpunkt |
| `stock` | einmal, Bestand als Text |
| `description` | null oder einmal, Beschreibung als Text |
| `tags` | einmal, darin null bis viele `tag`-Elemente mit Text |

Fachlich dürfen Preis und Bestand nicht negativ sein. Eine DTD prüft die
XML-Struktur, aber keine Zahlenwerte im Elementtext. Ein negativer Preis kann
daher wohlgeformt und DTD-gültig sein, obwohl er fachlich falsch ist.
Eine eigene fachliche Prüffunktion ist nicht Teil der Aufgabe.

Das DOM-Programm erhöht den Bestand von `A100` um 3 (12 auf 15), setzt bei
`A300` das Attribut `active` auf `true` und fügt bei `A210` in `tags` genau ein
neues `tag`-Element mit dem Text `regional` ein. Alle anderen Inhalte bleiben
erhalten. Kontrolliert besonders den Artikel `A200`, auch seine Sonderzeichen
und die Beschreibung. Vergleicht Inhalte; die XML-Einrückung darf sich ändern.

Jeder Lauf liest `data/catalog.xml` und schreibt `out/catalog-updated.xml`.
Das Original bleibt unverändert; ein zweiter Lauf liefert dasselbe Ergebnis.
