---
hide:
  - navigation
---

# "_XML-Katalog prüfen und bearbeiten_" – Taskdescription

## Einführung und Ziele

Das Bistro **Küche & Bar** erhält einen Artikelkatalog als XML-Datei. Ihr repariert
zwei fehlerhafte Beispiele, ergänzt eine DTD und führt drei Änderungen mit DOM aus.
Dabei unterscheidet ihr **wohlgeformt**, **DTD-gültig** und **fachlich korrekt**.

**Eine GK-Aufgabe · Einzelarbeit · 4 Unterrichtseinheiten à 50 Minuten.**
Die DTD- und Python-Gerüste sind vorgegeben; ihr ergänzt die markierten Stellen.
XPath, XSLT und ein eigener Importer gehören nicht zum Auftrag. Das Einlesen und
Speichern übernimmt das Gerüst. Alle Pflichtarbeiten einschließlich Abgabe sind
innerhalb der vier Einheiten vorgesehen.

## Zeitplan

| Einheit | Arbeitsschritt | Zeit |
| --- | --- | --- |
| 1 | Umgebung starten; XML ansehen und zwei Fehler reparieren | 10 + 40 Minuten |
| 2 | Drei DTD-Deklarationen ergänzen und vier Dateien prüfen | 50 Minuten |
| 3 | Drei DOM-Funktionen ergänzen und Ausgabe erzeugen | 50 Minuten |
| 4 | Ergebnisse prüfen und Protokoll abschließen; Kurzfragen; Puffer und Abgabe | 30 + 10 + 10 Minuten |

## Voraussetzungen und Einrichtung

Ihr kennt Python-Grundlagen, Dateien und Kommandozeile. **Python 3.14 ist vor
Unterrichtsbeginn installiert.** Ladet das [Arbeitsmaterial](material.zip) und
entpackt es. Arbeitet im Ordner `material`, in dem `tools.py` liegt.

<details class="info" markdown="1">
<summary>Start in den ersten zehn Minuten</summary>

In Windows / PowerShell:

```powershell
py -3.14 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -X utf8 tools.py parse data/catalog.xml
```

Falls `py -3.14` die Installation nicht findet, verwendet beim ersten Befehl den
vollständigen Pfad zu `python.exe`, in PowerShell mit `&` vor dem Pfad in Anführungszeichen.
Linux/macOS: `python3.14 -m venv .venv`, anschließend `.venv/bin/python` verwenden.

In allen folgenden Befehlen steht **`python` für den Interpreter eurer venv**,
unter Windows also `.\.venv\Scripts\python.exe`. Die README enthält die Einrichtungshilfe.
Getestete Basis: Python 3.14.7, lxml 6.1.3 und defusedxml 0.7.1
([Paketliste](requirements.txt)); die macOS-Einrichtung ist nicht separat getestet.

</details>

## Arbeitsauftrag

Der kurze [Datenvertrag](DATA_CONTRACT.md) beschreibt die Katalogstruktur.
Lasst `data/` und `cases/` unverändert. Ergänzt die Vorlagen in `work/` und speichert
XML-Ergebnisse in `out/`. Tragt eure Ergebnisse laufend in `work/protokoll.md` ein:
**acht Testzeilen und kurze Stichpunkte, insgesamt ungefähr eine Seite**.
Zusätzlichen Testcode müsst ihr nicht schreiben.

### 1. XML verstehen und reparieren

<details class="example" markdown="1">
<summary>Pflichtauftrag: zwei XML-Fehler beheben</summary>

Öffnet `data/catalog.xml`. Notiert das Wurzelelement sowie am Produkt A100 je ein
Beispiel für ein Attribut und ein Element mit Textinhalt.

Prüft `cases/01-unescaped.xml` und `cases/02-mismatched.xml`. Repariert beide in
Kopien namens `out/01-fixed.xml` und `out/02-fixed.xml`. Ändert nur das Nötige.

```bash
python -X utf8 tools.py parse cases/01-unescaped.xml
python -X utf8 tools.py parse out/01-fixed.xml
```

Der erste Aufruf soll einen Fehler melden, der zweite erfolgreich sein. Wiederholt
das für Fall 02. Haltet je Fall die ursprüngliche Meldung, eure Korrektur und die
erfolgreiche Prüfung in **einer** Testzeile fest. Die kleinen Beispiele benötigen
keine DTD-Prüfung.

</details>

### 2. Struktur mit einer DTD absichern

<details class="example" markdown="1">
<summary>Pflichtauftrag: drei DTD-Lücken und vier Prüfungen</summary>

Ergänzt die drei TODO-Stellen in `work/catalog.dtd` anhand des Datenvertrags:

1. `catalog` enthält null bis viele Produkte.
2. `product` enthält die vereinbarten Kindelemente in der richtigen Reihenfolge;
   `description` ist optional.
3. `product` benötigt `id` vom Typ `ID` und `active` mit den Werten `true` oder `false`.

Die übrigen Deklarationen sind vorgegeben. Als Hilfe: `,` beschreibt eine Reihenfolge,
`*` null bis viele Vorkommen, `?` null oder ein Vorkommen und `#REQUIRED` ein Pflichtattribut.

```bash
python -X utf8 tools.py validate data/catalog.xml work/catalog.dtd
```

Führt denselben Aufruf mit jeder der folgenden Dateien aus und dokumentiert vier Testzeilen:

| Datei | Erwartung |
| --- | --- |
| `data/catalog.xml` | DTD-gültig |
| `data/empty.xml` | DTD-gültig |
| `cases/05-missing-name.xml` | DTD-ungültig: Pflichtbestandteil fehlt |
| `cases/07-negative-price.xml` | DTD-gültig, aber fachlich fehlerhaft |

Die DTD wird separat übergeben; ihr müsst keinen DOCTYPE ergänzen.

</details>

### 3. Katalog mit DOM bearbeiten und erneut prüfen

<details class="example" markdown="1">
<summary>Pflichtauftrag: drei Funktionen ergänzen und Ergebnis kontrollieren</summary>

Ergänzt ausschließlich die drei TODO-Funktionen in `work/dom.py`. Die Produktauswahl,
das Laden des Originals und die UTF-8-Ausgabe sind fertig vorbereitet.

| Funktion | Produkt und Änderung |
| --- | --- |
| `update_stock(product)` | A100: Bestand um 3 erhöhen, von 12 auf 15 |
| `activate_product(product)` | A300: Attribut `active` auf `true` setzen |
| `add_regional_tag(document, product)` | A210: einen zusätzlichen `tag` mit Text `regional` anlegen |

Nutzt die vorhandenen Hilfsfunktionen `child_element` und `text_node`. Für die
Änderungen helfen `.data`, `setAttribute`, `createElement`, `createTextNode` und
`appendChild`. Die Kommentare im Gerüst erklären die Übergabeparameter.

```bash
python -X utf8 -m work.dom
python -X utf8 tools.py parse out/catalog-updated.xml
python -X utf8 tools.py validate out/catalog-updated.xml work/catalog.dtd
```

Öffnet anschließend die gespeicherte Datei: Stimmen die drei Änderungen? Bleiben
die vorhandenen Tags erhalten? Vergleicht A200 vollständig mit dem Original und
kontrolliert, dass `data/catalog.xml` unverändert ist. Die Einrückung darf abweichen.
Haltet diese Kontrollen zusammen mit der Parser-/DTD-Prüfung in einer Testzeile fest.

Startet das Skript erneut und prüft die Ausgabe nochmals. Weil jeder Lauf das Original
lädt, bleiben der Bestand **15** und genau ein Tag **regional** bei A210 erhalten.
Dokumentiert diesen zweiten Lauf in der letzten Testzeile.

</details>

## Fragestellungen

<details class="question" markdown="1">
<summary>Drei Kurzfragen – wenige Sätze genügen</summary>

1. Warum kann die Datei mit negativem Preis wohlgeformt und DTD-gültig sein,
   obwohl ihr Inhalt fachlich falsch ist?
2. Welche eurer DOM-Änderungen betrifft einen Textknoten, welche ein Attribut und
   welche erzeugt ein neues Element?
3. Warum lädt das Skript bei jedem Lauf das Original, und weshalb prüft ihr die
   tatsächlich gespeicherte Ausgabe erneut?

</details>

## Abgabe

Gebt **sechs Dateien** ab: `work/catalog.dtd`, `work/dom.py`, `work/protokoll.md`,
`out/01-fixed.xml`, `out/02-fixed.xml` und `out/catalog-updated.xml`.
Im Protokoll stehen die acht Testzeilen, die XML-Beispiele aus Abschnitt 1 und die
drei Kurzantworten. Kennzeichnet verwendete Quellen und KI-Unterstützung knapp.
Keine `.venv`, Bibliotheken oder Caches abgeben.

## Bewertungsvorschlag

Es gibt **eine Bewertung ausschließlich im GK-Bereich**. Die Stufen bauen aufeinander
auf; Gerüste und Hilfen dürfen ohne Abzug verwendet werden. Die Lehrkraft legt die
Bewertung vor dem Einsatz fest. Die [Checkliste](CHECK.md) enthält dieselben Kriterien.

<details class="success" markdown="1">
<summary>GK-Bewertungskriterien</summary>

### Grundlegend überwiegend

- [ ] Beide XML-Syntaxfehler repariert und die korrigierten Dateien erfolgreich eingelesen.
- [ ] Die drei DTD-Deklarationen ergänzt: Normal- und Leerkatalog sind gültig, der Katalog ohne Namen ist ungültig.
- [ ] Alle drei DOM-Änderungen umgesetzt; die gespeicherte Ausgabe ist wohlgeformt und DTD-gültig.
- [ ] Wohlgeformtheit, DTD-Gültigkeit und fachliche Korrektheit am Beispiel des negativen Preises unterschieden.

### Grundlegend vollständig

- [ ] Wurzelelement, Attribut und Text am Katalog richtig benannt und alle drei Kurzfragen fachlich richtig beantwortet.
- [ ] Übrige Inhalte erhalten; A200 mit dem Original verglichen, Original unverändert und zweiter Lauf mit Bestand 15 sowie genau einem neuen Tag nachgewiesen.
- [ ] Alle acht Testzeilen mit Soll, Ist und kurzer Erklärung ausgefüllt; Arbeitsdateien und XML-Ergebnisse vollständig und erneut ausführbar abgegeben.

</details>

## Quellen

Bei Bedarf findet ihr XML-, DTD- und DOM-Dokumentation in der
[Primärquellenliste](../SOURCES.md). Eine vollständige Lektüre ist nicht Teil der Aufgabe.

*Mit KI-Unterstützung erstellt. Version 20260920v2 – GK-Aufgabe für vier Unterrichtseinheiten.*
