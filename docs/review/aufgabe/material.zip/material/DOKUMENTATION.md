# Lieferantenangebote mit XML vergleichen

Verfasser: **[Name]**

Datum: **[Datum]**

Nutze kurze Absätze und Stichpunkte; ungefähr ein bis zwei Seiten plus Screenshot
genügen. Beschreibe, was durchgeführt wurde, beispielsweise „Die Antwort wurde
abgerufen …“. Entferne diese Ausfüllhinweise bei der Abgabe.

## 1. Einführung

[Zwei Sätze: Welche Einkaufsentscheidung sollte unterstützt werden und warum ist ein Vergleich sinnvoll?]

## 2. Projektbeschreibung

[Zwei Sätze zum Weg vom Webservice über das eigene XML zur Empfehlung.]

## 3. Theorie

Beantworte die sieben Grundfragen der Angabe während der Bearbeitung. Bei 1/5
genügen Stichpunkte, bei 2/5 und 3/5 ein bis drei kurze Sätze. Insgesamt sind
etwa 15–20 Minuten innerhalb der vier UE vorgesehen.

1. **[1/5] Wurzelelement:** [Bedeutung und Name in deiner Datei.]
2. **[1/5] Element, Attribut und Text:** [Die vier Bestandteile des Beispiels benennen.]
3. **[1/5] Zweck einer DTD:** [Aufgabe und eine eigene Strukturregel.]
4. **[2/5] Häufigkeit und Reihenfolge:** [Bedeutung von + und ?, erlaubte Anzahl und Position des Hinweises.]
5. **[2/5] Pflichtattribut und erlaubte Werte:** [#REQUIRED, Enumeration und Beurteilung der beiden Fälle.]
6. **[3/5] Wohlgeformt oder DTD-gültig:** [Kopie A und B einordnen und den Unterschied erklären.]
7. **[3/5] Grenze der DTD:** [Negativen Kurswert einordnen und nötige zusätzliche Regel nennen.]

## 4. Arbeitsschritte

Anfrage-URL: [URL] · Kursdatum: [EffectiveDate] · Abruf: [Datum/Uhrzeit]

Verwendet: [Liveantwort / mitgelieferte Ersatzantwort; bei Ersatz kurz begründen]

Übernommene Werte in PLN je Währungseinheit: EUR [Wert], CZK [Wert], PLN 1.

[Beschreibe kurz deine XML-Struktur und eine selbst erstellte DTD-Regel. Verweise auf die beigelegten Dateien.]

| Eingabe und Prüfung | Erwartung | Tatsächliches Ergebnis und kurze Erklärung |
| --- | --- | --- |
| Eigenes korrektes XML: XML- und DTD-Prüfung | beide erfolgreich | |
| Syntaxfehler-Kopie: XML-Prüfung | Fehler | |
| Strukturfehler-Kopie: XML- und DTD-Prüfung | wohlgeformt, DTD-ungültig | |

Manueller Rechencheck für Lieferant PL oder CZ: [Eingaben, eingesetzte Kurse, Rechnung und Endbetrag]

![Vergleich mit den eigenen XML-Daten](vergleich.png)

## 5. Zusammenfassung

[Empfehlung in zwei bis drei Sätzen: Lieferant, Gesamtkosten, Ersparnis oder Gleichstand gegenüber AT.
Bei Bedarf kurze Anmerkung zu Schwierigkeiten.]

## 6. Quellen

[Titel, Herausgeber, URL und Abrufdatum der verwendeten Quellen. Verweise im Text bei Bedarf als [1], [2] usw.]

KI-Unterstützung: [Werkzeug und Art der Unterstützung / keine]
