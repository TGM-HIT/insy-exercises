# Testprotokoll

Team, Datum, Versionen und lokale URL:

| ID | Benutzer/Rolle | Ausgangsdaten | Aktion | Soll | Ist / Nachweis | Bewertung |
| --- | --- | --- | --- | --- | --- | --- |
| | | | | | | |

## Grenzen der Pilotinstallation

Welche Rechte gelten global, welche nur auf eigenen Beiträgen? Welche Klassen-/
Abteilungsgrenze ist nur geplant? Beschreibt den Gegenversuch mit fremder Kategorie.

## Wiederherstellung

Sicherungsname, Quell-/Zielprojekt, Ports, Versionsstand, geprüfter Beitrag,
Medium, Rollen und Frontend. Keine Passwörter ins Protokoll aufnehmen.
