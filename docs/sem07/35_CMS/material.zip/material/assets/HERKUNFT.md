# Herkunft der Gestaltungsmittel

Logo und drei TGM-Schriften stammen aus den vom Kursbetreuer bereitgestellten
Dateien in cms_alt. Die Schriften wurden nur umbenannt. TGMLogo.svg war ein SVG-
Container um ein PNG mit 103 × 53 Pixeln; TGMLogo.png enthält exakt diese Bilddaten.
Keine neue Zeichnung und keine künstliche Hochskalierung. Für WordPress genügt
das PNG; ein Plugin zur generellen Freigabe von SVG-Uploads ist nicht nötig.

Verwendet das kleine Logo ungefähr in Originalgröße. Die Schriftdateien enthalten
keine hier separat beigefügte Lizenzdatei; dieses Paket erteilt keine zusätzlichen
Marken- oder Weiterverbreitungsrechte. Einsatz als lokale Unterrichtsdemonstration.
Für eine tatsächliche Veröffentlichung die freigegebenen Schulmaterialien verwenden.
