# Berechtigungsentwurf – selbst ausfüllen

Unterscheidet schulweites Zielmodell und lokale Pilotinstallation. Dokumentiert bei
jeder Aktion: erlaubt/verboten, auf welchen Inhalten, technische Rolle und Test.

| Schulrolle | Eigene Entwürfe | Fremde Beiträge bearbeiten | Veröffentlichen | Seiten bearbeiten | Medien | Benutzer/Rollen | Plugins/Theme | Gewünschter Geltungsbereich | Pilotrolle / Abweichung |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Schüler | | | | | | | | | |
| Klassenadministrator | | | | | | | | | |
| Lehrer | | | | | | | | | |
| Redakteur | | | | | | | | | |
| Abteilungsadministrator | | | | | | | | | |
| Administrator | | | | | | | | | |

## UML-Akteurmodell

Eigenes Diagramm ergänzen. Generalisierung bedeutet Übernahme der Anwendungsfälle
des allgemeineren Akteurs, nicht automatisch Vorgesetzten- oder WordPress-Vererbung.
Bei unpassender Hierarchie ein Use-Case-Diagramm ohne künstliche Vererbung verwenden.
