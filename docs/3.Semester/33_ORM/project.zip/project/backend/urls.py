from django.urls import path
from . import views, support

urlpatterns = [
    path("", views.index, name="index"),
    path("recipe/<int:recipeid>", views.recipe, name="recipe"),
    path("by-ingredient/<int:ingredientid>", views.by_ingredient, name="by_ingredient"),
    path("new", views.new, name="new"),
    path("remove/<int:recipeid>", views.remove, name="remove"),
    path("tools/", support.tools, name="tools"),
]
