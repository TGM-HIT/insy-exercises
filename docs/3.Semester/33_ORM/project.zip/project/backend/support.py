"""Vorgegebene Infrastruktur für den JSON-Testclient; keine ORM-Lösung."""
from functools import wraps
from django.http import JsonResponse
from django.shortcuts import render
from django.contrib.admin.views.decorators import staff_member_required
from django.views.decorators.http import require_GET

def staff_api(view):
    @wraps(view)
    def wrapped(request, *args, **kwargs):
        if not (request.user.is_authenticated and request.user.is_active and request.user.is_staff):
            return JsonResponse({"error": "Admin-Anmeldung erforderlich."}, status=403)
        return view(request, *args, **kwargs)
    return wrapped

@staff_member_required
@require_GET
def tools(request):
    return render(request, "backend/tools.html")
