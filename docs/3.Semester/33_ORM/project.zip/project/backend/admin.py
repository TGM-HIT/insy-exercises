from django.contrib import admin

# Eure Modelle hier registrieren. Eine aussagekräftige __str__-Methode hilft.
