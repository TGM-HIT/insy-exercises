"use strict";
document.querySelector("#request-form").addEventListener("submit", async (event) => {
  event.preventDefault();
  const output = document.querySelector("#response");
  const button = event.currentTarget.querySelector("button");
  const remove = document.querySelector("#action").value === "remove";
  const id = document.querySelector("#recipe-id").value;
  if (remove && !/^[1-9]\d*$/.test(id)) {
    output.textContent = "Bitte eine positive ganzzahlige Rezept-ID eingeben.";
    return;
  }
  button.disabled = true;
  try {
    const response = await fetch(remove ? `/remove/${id}` : "/new", {
      method: "POST", mode: "same-origin", credentials: "same-origin",
      headers: {"Content-Type": "application/json",
        "X-CSRFToken": document.querySelector('[name="csrfmiddlewaretoken"]').value},
      body: remove ? "{}" : document.querySelector("#payload").value,
    });
    const text = await response.text();
    let formatted = text;
    try { formatted = JSON.stringify(JSON.parse(text), null, 2); } catch (_) { /* HTML error body */ }
    output.textContent = `HTTP ${response.status}\n${formatted}`;
  } catch (error) {
    output.textContent = `Anfrage fehlgeschlagen: ${error.message}`;
  } finally { button.disabled = false; }
});
