from django.http import JsonResponse
from django.shortcuts import render
from django.views.decorators.http import require_GET, require_POST
from .support import staff_api

@require_GET
def index(request):
    # TODO: Liste aus der Datenbank, Zutatenanzahl und Links ergänzen.
    return render(request, "backend/index.html")

@require_GET
def recipe(request, recipeid):
    # TODO: Detailansicht; unbekannte ID -> 404.
    return JsonResponse({"error": "Noch nicht implementiert."}, status=501)

@require_GET
def by_ingredient(request, ingredientid):
    # TODO: Rezepte mit dieser Zutat; unbekannte Zutat -> 404.
    return JsonResponse({"error": "Noch nicht implementiert."}, status=501)

@require_POST
@staff_api
def new(request):
    # TODO: JSON prüfen und Rezept mit Zutatenpositionen atomar speichern.
    return JsonResponse({"error": "Noch nicht implementiert."}, status=501)

@require_POST
@staff_api
def remove(request, recipeid):
    # TODO: Rezept löschen; Zutatenstamm und Benutzer behalten.
    return JsonResponse({"error": "Noch nicht implementiert."}, status=501)
