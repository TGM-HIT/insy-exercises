from django.db import models

# Eure Aufgabe: fachliches Modell aus TASK.md entwerfen und implementieren.
# Djangos Benutzer existiert bereits; kein eigenes User-Modell anlegen.
