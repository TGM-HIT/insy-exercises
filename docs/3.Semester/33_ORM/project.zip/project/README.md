# Bistro-Rezeptbuch – Startprojekt

Stand 2026-09-13: Python 3.14.7, Django 5.2.17 LTS, SQLite aus Python.
Die verbindliche Aufgabenbeschreibung und Bewertung stehen im Kurs unter:
https://tgm-hit.github.io/insy-exercises/3.Semester/33_ORM/TASK/

## Windows (PowerShell)

Im entpackten Ordner mit `manage.py`:

```powershell
py -3.14 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe manage.py migrate
.\.venv\Scripts\python.exe manage.py createsuperuser
.\.venv\Scripts\python.exe manage.py runserver
```

## Linux / macOS

```bash
python3.14 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python manage.py migrate
.venv/bin/python manage.py createsuperuser
.venv/bin/python manage.py runserver
```

Die Aktivierung der venv ist optional, wenn ihr wie hier ihren Interpreter direkt aufruft.

## Docker Compose

Docker Desktop muss Linux-Container ausführen können.

```bash
docker compose build
docker compose run --rm web python manage.py migrate
docker compose run --rm web python manage.py createsuperuser
docker compose up -d
docker compose logs --tail 30 web
```

Öffnet http://127.0.0.1:8000/ und http://127.0.0.1:8000/admin/.
Unter `/tools/` gibt es nach der Admin-Anmeldung einen fertigen JSON-Testclient.

Port belegt? Legt eine `.env` neben `compose.yaml` an mit `HOST_PORT=8001`;
startet erneut und verwendet im Browser Port 8001. Bei venv: `runserver 127.0.0.1:8001`.

## Eure Arbeitsdateien

- `backend/models.py`: eigenes Modell; noch keine Rezepttabellen vorhanden.
- `backend/admin.py`: Modelle registrieren.
- `backend/views.py`: ORM und Antworten implementieren; TODO-Endpunkte liefern 501.
- `backend/urls.py`: vorbereitete URL-Zuordnung; nach Bedarf erweitern.
- `backend/templates/backend/`: HTML-Vorlage; Liste und Detailansicht selbst bauen.
- `backend/support.py`, `static/backend/tools.js`: fertige Anmelde-/CSRF-Infrastruktur.

Nach Modelländerungen: `manage.py makemigrations backend`, danach `manage.py migrate`.
Setzt davor euren Interpreter oder `docker compose exec web python` ein.
Migrationen gehören zum Quellcode und zur Abgabe. Sie werden nicht automatisch erzeugt.
`manage.py check` prüft Django-Konfiguration, nicht die Vollständigkeit eurer Lösung.

Docker bindet den Ordner nach `/app` ein. Code und `db.sqlite3` liegen deshalb am Host.
`docker compose down` beendet Container; die Datenbankdatei bleibt erhalten.
Startet venv und Docker für denselben Ordner abwechselnd, nicht gleichzeitig.
Neue Pakete erfordern ein erneutes `docker compose build` und eine venv-Installation.

CSRF und die vorgegebenen Schreibschutz-Dekoratoren bleiben aktiv. Nach einer erneuten
Admin-Anmeldung die Testseite neu laden (der CSRF-Token kann sich ändern).
Exportiert mit `python -X utf8 manage.py dumpdata backend --natural-foreign --indent 2 --output recipes.json`.
Verwendet dafür den venv-Interpreter oder davor `docker compose exec web`.
`-X utf8` ist unter Windows/Python 3.14 für einen wieder importierbaren Export mit Umlauten wichtig.
Die Umgebung bindet lokal und verwendet DEBUG sowie einen öffentlichen Entwicklungsschlüssel.
Sie ist eine Entwicklungsumgebung für eigene Demodaten.
