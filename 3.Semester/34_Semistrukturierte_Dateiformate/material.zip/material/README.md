# Lieferantenkatalog – Arbeitsmaterial

Python 3.14.7 · lxml 6.1.3 · SaxonC-HE 13.0.0 · defusedxml 0.7.1.
Entpackt das ZIP und arbeitet im Ordner `material`, in dem `tools.py` liegt.

## Windows / PowerShell

```powershell
py -3.14 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -X utf8 tools.py versions
.\.venv\Scripts\python.exe -X utf8 tools.py parse data/catalog.xml
```

Linux/macOS: `python3.14 -m venv .venv`, anschließend `.venv/bin/python` anstelle des Windows-Pfads verwenden.
Eine aktive venv ist nicht erforderlich, wenn ihr deren Interpreter direkt aufruft.

## Docker-Alternative

```bash
docker compose build
docker compose run --rm tools python tools.py versions
docker compose run --rm tools python tools.py parse data/catalog.xml
```

Compose verwendet Linux-Container und bindet den Ordner nach `/work` ein. Ergebnisse in `out/`
bleiben am Host erhalten. Die Werkzeuge benötigen nach Installation/Build keinen Netzwerkzugriff;
der Compose-Lauf deaktiviert das Netzwerk. Docker ist eine Alternative, keine zusätzliche Bewertungsanforderung.
Die nativen Paket-Wheels werden unter Windows/Linux x86-64 geprüft; macOS wurde nicht nachgebaut.

## Was ihr bearbeitet

- `data/`: gleiche Daten in XML, JSON und CSV. Originale erhalten, Änderungen nach `out/` schreiben.
- `cases/`: kleine absichtliche Fehlerfälle und ein harmloser DOCTYPE-Test.
- `work/catalog.dtd`, `work/queries.json`, `work/catalog.xsl`: euer Schema, eure Abfragen und Transformation.
- `work/dom.py`, `work/import_catalog.py`, `work/stream_catalog.py`: noch offene Python-Lösungen.
- `DATA_CONTRACT.md`: vereinbarte Struktur und Geschäftsregeln.
- `tools.py`: fertige Infrastruktur; Parsing allein bestätigt keine fachliche Korrektheit.

Nachfolgend steht `python` für den Interpreter eurer venv; unter PowerShell z. B.
`.\.venv\Scripts\python.exe`. Verwendet `-X utf8` auch bei eigenen Skripten und gebt beim
Öffnen von Textdateien `encoding="utf-8"` an. CSV-Dateien mit `newline=""` öffnen.

```bash
python -X utf8 tools.py validate data/catalog.xml work/catalog.dtd
python -X utf8 tools.py xpath data/catalog.xml work/queries.json q1
python -X utf8 tools.py xslt data/catalog.xml work/catalog.xsl out/catalog.html
python -X utf8 tools.py generate out/large.xml --count 100000
python -X utf8 -m work.dom
python -X utf8 -m work.import_catalog
python -X utf8 -m work.stream_catalog
```

Die leere DTD, leeren Abfragen und Python-TODOs funktionieren erst nach eurer Bearbeitung.
Das XSLT-Gerüst erzeugt zunächst nur eine Platzhalterseite. Eine bestandene Umgebungsprüfung
bedeutet daher nicht, dass die Aufgaben schon gelöst sind.

Eigene Python-Dateien unter `work/` starten mit `-m work.dom` usw. vom Materialordner aus.
So könnt ihr `from tools import load_dom, load_tree` verwenden, ohne Suchpfade anzupassen.
`load_dom` liefert ein DOM-Dokument; `load_tree` liefert ein lxml-Element.
Beide lehnen DOCTYPE und benutzerdefinierte Entities ab. Die DTD wird für die Validierung
bewusst separat aus eurer lokalen Datei geladen. Schreibt keine externe DTD in die XML-Datei.
Für den großen Streaming-Versuch nutzt ihr `defusedxml.ElementTree.iterparse` direkt
mit `forbid_dtd=True, forbid_entities=True, forbid_external=True`.

Verwendet nur die gelieferten oder selbst erstellte lokale DTDs, XPath-Ausdrücke und Stylesheets.
Diese Werkzeuge sind keine Sandbox für fremden ausführbaren XSLT-Code. Öffnet fertiges HTML
im Browser; eine XML-Stylesheet-Verknüpfung oder Browser-XSLT wird nicht benötigt.
