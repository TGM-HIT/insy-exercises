"""Vorgegebene lokale Werkzeuge. Enthält keine fachlichen Aufgabenlösungen."""
import argparse
import json
from pathlib import Path
import sys
import pyexpat
from importlib.metadata import version
from defusedxml import ElementTree as safe_et
from defusedxml import minidom as safe_dom
from lxml import etree
from saxonche import PySaxonProcessor

NS = 'urn:tgm:insy:catalog:1'

def read_checked(path):
    # Für kleine Unterrichtsdateien. Der Streaming-Versuch nutzt iterparse separat.
    raw = Path(path).read_bytes()
    safe_et.fromstring(raw, forbid_dtd=True, forbid_entities=True, forbid_external=True)
    return raw

def load_dom(path):
    return safe_dom.parse(str(path), forbid_dtd=True, forbid_entities=True, forbid_external=True)

def load_tree(path):
    raw = read_checked(path)
    return etree.fromstring(raw, parser=etree.XMLParser(resolve_entities=False, no_network=True, load_dtd=False))

def evaluate(path, expression):
    xml = read_checked(path).decode('utf-8-sig')
    with PySaxonProcessor(license=False) as processor:
        xpath = processor.new_xpath_processor()
        xpath.set_language_version('3.1')
        xpath.declare_namespace('c', NS)
        xpath.declare_namespace('map', 'http://www.w3.org/2005/xpath-functions/map')
        xpath.set_context(xdm_item=processor.parse_xml(xml_text=xml))
        value = xpath.evaluate(expression)
        return [] if value is None else [str(value.item_at(i)) for i in range(value.size)]

def transform(xml_path, xsl_path, output, min_stock=1):
    if min_stock < 1:
        raise ValueError('min-stock muss mindestens 1 sein.')
    xml = read_checked(xml_path).decode('utf-8-sig')
    read_checked(xsl_path)
    # Nur selbst erstellte, lokale Stylesheets verwenden: XSLT ist ausführbarer Code.
    with PySaxonProcessor(license=False) as processor:
        compiler = processor.new_xslt30_processor()
        executable = compiler.compile_stylesheet(stylesheet_file=str(Path(xsl_path).resolve()))
        executable.set_parameter('min-stock', processor.make_integer_value(min_stock))
        result = executable.transform_to_string(xdm_node=processor.parse_xml(xml_text=xml))
    target = Path(output); target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(result, encoding='utf-8')

def generate_large(output, count):
    if count < 1 or count > 1000000:
        raise ValueError('Die Anzahl muss zwischen 1 und 1000000 liegen.')
    target = Path(output); target.parent.mkdir(parents=True, exist_ok=True)
    with target.open('w', encoding='utf-8', newline='\n') as stream:
        stream.write('<?xml version="1.0" encoding="UTF-8"?>\n<catalog currency="EUR" updated="2026-09-13">\n')
        for i in range(count):
            stream.write(f'<product id="G{i:07d}" active="true"><name>Testartikel {i}</name><category>Test</category><unit>Stück</unit><price>1.25</price><stock>2</stock><tags/></product>\n')
        stream.write('</catalog>\n')

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='command', required=True)
    sub.add_parser('versions')
    parse = sub.add_parser('parse'); parse.add_argument('xml')
    validate = sub.add_parser('validate'); validate.add_argument('xml'); validate.add_argument('dtd')
    xpath = sub.add_parser('xpath'); xpath.add_argument('xml'); xpath.add_argument('queries'); xpath.add_argument('key')
    xslt = sub.add_parser('xslt'); xslt.add_argument('xml'); xslt.add_argument('xsl'); xslt.add_argument('output'); xslt.add_argument('--min-stock', type=int, default=1)
    large = sub.add_parser('generate'); large.add_argument('output'); large.add_argument('--count', type=int, default=100000)
    args = parser.parse_args()
    try:
        if args.command == 'versions':
            print(sys.version.split()[0])
            for package in ['lxml', 'saxonche', 'defusedxml']: print(package, version(package))
            print('libxml2', '.'.join(map(str, etree.LIBXML_VERSION)), 'Expat', pyexpat.EXPAT_VERSION)
            with PySaxonProcessor(license=False) as processor: print(processor.version)
        elif args.command == 'parse':
            tree = load_tree(args.xml); print('Wohlgeformt:', tree.tag)
        elif args.command == 'validate':
            tree = load_tree(args.xml)
            with Path(args.dtd).open('rb') as stream: dtd = etree.DTD(stream)
            if not dtd.validate(tree): raise ValueError(str(dtd.error_log))
            print('Gültig bezüglich der angegebenen DTD.')
        elif args.command == 'xpath':
            expression = json.loads(Path(args.queries).read_text(encoding='utf-8'))[args.key]
            if not expression.strip(): raise ValueError('XPath-Ausdruck ist noch leer.')
            print(json.dumps(evaluate(args.xml, expression), ensure_ascii=False, indent=2))
        elif args.command == 'xslt':
            transform(args.xml, args.xsl, args.output, args.min_stock); print('HTML geschrieben:', args.output)
        elif args.command == 'generate':
            generate_large(args.output, args.count); print('Testdatei erstellt:', args.count, 'Produkte')
    except Exception as error:
        print(f'FEHLER: {error}', file=sys.stderr)
        return 1
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
