"""Lest mit load_dom ein, ändert den DOM und speichert nach out/catalog-updated.xml."""

raise NotImplementedError("Hier beginnt eure eigene Lösung; siehe TASK.md.")
