"""Verarbeitet den großen Katalog ereignisweise; baut keine komplette Ergebnisliste auf."""

raise NotImplementedError("Hier beginnt eure eigene Lösung; siehe TASK.md.")
