<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="3.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
  <xsl:output method="html" html-version="5" encoding="UTF-8"/>
  <xsl:template match="/">
    <html lang="de"><head><meta charset="utf-8"/><title>Lieferantenkatalog</title></head>
    <body><h1>Lieferantenkatalog</h1><p>TODO: Tabelle durch Transformation der XML-Daten erzeugen.</p></body></html>
  </xsl:template>
</xsl:stylesheet>
