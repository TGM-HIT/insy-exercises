"""Prüft Struktur und Geschäftsregeln und exportiert nach out/import.json."""

raise NotImplementedError("Hier beginnt eure eigene Lösung; siehe TASK.md.")
